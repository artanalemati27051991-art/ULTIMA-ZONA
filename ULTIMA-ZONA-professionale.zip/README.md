# ULTIMA-ZONA

Sito web statico pronto per GitHub Pages.

## Struttura

```text
ULTIMA-ZONA/
├── .github/
│   └── workflows/
│       └── build.yml
├── www/
│   └── index.html
└── README.md
```

## Pubblicazione

Il workflow in `.github/workflows/build.yml` pubblica automaticamente il contenuto
della cartella `www/` su GitHub Pages ogni volta che viene effettuato un push sul
branch `main`.

### Impostazione GitHub Pages

Nel repository:

**Settings → Pages → Build and deployment → Source → GitHub Actions**

Dopo il primo push sul branch `main`, GitHub Actions eseguirà il deployment.

## Sito

La pagina principale si trova in:

`www/index.html`
